<!-- TimeLine -->
<h4 class="page-title"> <?= strtoupper($deskripsi) ?></h4>
<div class="row">
    <div class="col-md-12">
        <div class="notif" data-flashdata="<?= $this->session->flashdata('flash'); ?>"></div>
        <div class="flash-data" data-flashdata="<?= $this->session->flashdata('result'); ?>"></div>
        <ul class="timeline">
            <li>
                <div class="timeline-badge info"><i class="flaticon-price-tag"></i></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4 class="timeline-title">Cara Melakukan pengisian Monitoring APAR</h4>
                    </div>
                    <div class="timeline-body">
                        <p>1. Pilih menu <a href="<?= base_url('mon-apar') ?>" class=""> Monitoring APAR</a></p>
                        <p>2. Klik Tambah Data</p>
                        <p>3. Pilih APAR yang akan di lakukan pengecekan</p>
                        <p>4. Pilih Tanggal Refill Sebelumnya</p>
                        <p>5. Masukkan Timbangan dari APAR</p>
                        <p>6. Tambahkan Foto dokumentasi (Boleh lebih dari 1 foto)</p>
                        <p>7. Isi Kuesioner dengan menjawab semua pertanyaan yang ada</p>
                        <p>8. Tambahkan keterangan apabila dibutuhkan</p>
                        <p>9. Klik Tombol Simpan</p>
                        <hr>
                    </div>
                </div>
            </li>
            <li class="timeline-inverted">
                <div class="timeline-badge success"><i class="flaticon-attachment"></i></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4 class="timeline-title">Cara Melakukan pengisian Monitoring Firealarm</h4>
                    </div>
                    <div class="timeline-body">
                        <p>1. Pilih menu <a href="<?= base_url('mon-firealarm') ?>" class="">Monitoring Firealarm</a></p>
                        <p>2. Klik Tambah Data</p>
                        <p>3. Pilih Firealarm yang akan di lakukan pengecekan</p>
                        <p>4. Tambahkan Foto dokumentasi (Boleh lebih dari 1 foto)</p>
                        <p>5. Isi Kuesioner dengan menjawab semua pertanyaan yang ada</p>
                        <p>6. Tambahkan keterangan apabila dibutuhkan</p>
                        <p>7. Klik Tombol Simpan</p>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>