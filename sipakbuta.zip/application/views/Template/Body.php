<!DOCTYPE html>
<html lang="en">

<?= $_head; ?>
<div class="wrapper">

    <?= $_navbar ?>

    <?= $_sidebar; ?>

    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
                <?= $_content; ?>

                <?= $_footer; ?>